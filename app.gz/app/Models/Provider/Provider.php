<?php

namespace App\Models\Provider;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Database\Factories\CategorieFactory;
class Provider extends Model
{
    /** @use HasFactory<\Database\Factories\ProviderFactory> */
    use HasFactory;

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function categorie()
    {
        return $this->belongsTo(Categorie::class);
    }

    public function services()
    {
        return $this->hasMany(Service::class);
    }

    public function plannings()
    {
        return $this->hasMany(Planning::class);
    }

    public function exceptions()
    {
        return $this->hasMany(Exception::class);
    }
}
