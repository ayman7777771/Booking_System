<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Exception extends Model
{
    /** @use HasFactory<\Database\Factories\ExceptionFactory> */
    use HasFactory;

    public function provider()
    {
        return $this->belongsTo(Provider::class);
    }
}
